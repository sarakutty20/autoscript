#   Description:
#   CDS_WO_MILES_COMP.py
#   Complete Value Stream Approval, Senior Approval and Completed
#   VSA,   
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    04/10/2016
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A         S Ananthan
#    
#   Launch Point Variables
#   ----------------------
#                                         Action launch point
#
#   Relationships
#   -------------

from java.util import Calendar 
from java.util import Date 
from psdi.server import MXServer 
from psdi.mbo import MboConstants 
from psdi.mbo import SqlFormat
from psdi.mbo import MboSetEnumeration
import sys


v_wonum = mbo.getString("WONUM")
v_miles_tbc = mbo.getString("WOLO5")
v_cds_hlevel = mbo.getInt("CDS_HLEVEL")
if(v_cds_hlevel == 1):
    v_whereclauseql = "istask = 1 and siteid = 'BIRM' and cds_ms_code ='"+str(v_miles_tbc)+"' and parent = '"+str(v_wonum)+"'"
    print "==v_whereclauseql========="+str(v_whereclauseql)
    woactivityset  = mbo.getMboSet('$$WOMS'+str(v_miles_tbc),'WORKORDER',v_whereclauseql)
    #print '******** Inside CDS_WO_MILES_VSA.py **************************'    
    #COMP milestone
    try: 
        if(woactivityset.moveFirst() is not None):	
            woactivitymbo = woactivityset.getMbo(0)
            v_currentstatus = woactivitymbo.getString("STATUS")
            print "======wo task v_currentstatus==========="+str(v_currentstatus)
            v_actfinishdate = woactivitymbo.getDate("ACTFINISH")
            if (v_currentstatus == "INPRG"):
                print "======Inside INPRG============="
                woactivitymbo.setValue("ACTFINISH", MXServer.getMXServer().getDate())
                woactivitymbo.changeStatus("COMP", MXServer.getMXServer().getDate(),"Automatic status")
    except:
        print "Exception: ", sys.exc_info()