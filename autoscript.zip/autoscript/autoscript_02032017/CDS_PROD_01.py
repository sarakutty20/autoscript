#   Description:
#   CDS_PROD_01.py
#   Script to generate Maximo ITEM
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    11/02/2016
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                        N/A             W Mahmud
#
#    
#   Relationships
#   -------------
#
from psdi.mbo import Mbo
from psdi.mbo import MboSet
from psdi.mbo import MboConstants
from psdi.server import MXServer

# Initialise values
ITEMNUM = mbo.getString("PRODUCT_ID")
ITEMDESC = mbo.getString("PRODUCT_DESC")
ITEMSETID = "ITEMSET"
ORGID = "RRCDS"
STATUS_COMMENT = "Automatically Set"
STATUS_PEND = "PENDING"
STATUS_ACTIVE = "ACTIVE"
CATEGORY_STK = "STK"

commodityGroup = ""
commodityCode = ""

# Update Value stream if available
partMboSet = mbo.getMboSet("CDS_PART")
if partMboSet.count() > 0:
    # Take first record
    partMbo = partMboSet.getMbo(0)
    userField1 = partMbo.getString("USER_FIELD_1")
    
    # Value stream is first 2 characters
    uf1 = str(userField1[:2])
    if uf1 == "Y-":
        commodityGroup = uf1
    elif uf1 == "S-":
        commodityGroup = uf1
    else:
        # Take first character of user field 1
        commodityGroup = str(userField1[:1])

# Copy details to Maximo ITEM
# Check to ensure does not exist
v_whereclauseql = "itemnum = '" + ITEMNUM + "'"
itemMboSet = mbo.getMboSet('$$ITEM','ITEM',v_whereclauseql)
if itemMboSet.count() == 0:
    # Add item
    itemMbo = itemMboSet.add()
    itemMbo.setValue("ITEMNUM",ITEMNUM)
    itemMbo.setValue("ITEMSETID",ITEMSETID,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    itemMbo.setValue("DESCRIPTION",ITEMDESC)
    itemMbo.setValue("STATUS",STATUS_PEND)
    itemMbo.setValue("COMMODITYGROUP",commodityGroup)



    # Add itemorginfo
    itemOrgInfoMboSet = itemMbo.getMboSet("ITEMORGINFO")
    itemOrgInfoMbo = itemOrgInfoMboSet.add()
    itemOrgInfoMbo.setValue("ITEMNUM",ITEMNUM)
    itemOrgInfoMbo.setValue("ITEMSETID",ITEMSETID,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    itemOrgInfoMbo.setValue("STATUS",STATUS_PEND)
    itemOrgInfoMbo.setValue("ORGID",ORGID)
    itemOrgInfoMbo.setValue("CATEGORY",CATEGORY_STK,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)

    # Change status
    itemMbo.changeStatus(STATUS_ACTIVE, MXServer.getMXServer().getDate(), STATUS_COMMENT)
    itemOrgInfoMbo.changeStatus(STATUS_ACTIVE, MXServer.getMXServer().getDate(), STATUS_COMMENT)