#   Description:
#   CDS_WO_APPLYBURDENMARKUP.py
#   Apply burden rate and markup to gross totals
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    05/02/2016
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A         W Mahmud
#   1.1      Inculded purchase 
#				and manufacture breakdown               N/A        Saravanan
#   1.2      Included to apply different diff markup    N/A        Saravanan    
#   Launch Point Variables
#   ----------------------
#                                         Action launch point
#
#   Relationships
#   -------------
#   CDS_VENDOR2COMP
#   CDS_COMM_BURDENRATE
#   CDS_MARKUP_LIST

from java.util import Calendar 
from java.util import Date 
from psdi.app.report import ReportUtil 
from psdi.server import MXServer 
from psdi.mbo import MboConstants 
from psdi.mbo import SqlFormat


# Initialise defaults
v_cdscustmarkup = 0
v_burratepercen = 0
v_exchangerate 	= 0
v_makebuydecision = mbo.getString("CDS_MAKEBUY_DECISION")
v_quote_type = mbo.getString("CDS_QUOTE_TYPE")
v_different_markup = mbo.getString("CDS_DIFF_MARKUP")

# Set Markup
custmarkupmboset = mbo.getMboSet("CDS_VENDOR2COMP")
if (custmarkupmboset.moveFirst() is not None ):
    v_cdscustmarkup = custmarkupmboset.getMbo(0).getDouble("CDS_MARKUP")	
mbo.setValue("CDS_CUST_MARKUP",v_cdscustmarkup,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)

# Apply different markup rate percentage i.e from COMPANIES screen 
if(v_makebuydecision  =="MAKE" and v_different_markup != ""):
	diffmarkupmboset = mbo.getMboSet("CDS_MARKUP_LIST")
	v_cdscustmarkup = diffmarkupmboset.getMbo(0).getDouble("PERCENTAGE")

# Set Burden Rate
commmboset = mbo.getMboSet("CDS_COMM_BURDENRATE")					
if(commmboset.moveFirst() is not None):							
    v_burratepercen = commmboset.getMbo(0).getDouble("CDS_BURDEN_RATE")
mbo.setValue("CDS_BURDEN_RATE",v_burratepercen,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)	

# Calculate Net Cost for each qty
for v_req_qty in range(1,5):
    v_unitcost = mbo.getDouble("CDS_COST_GROSS_QTY_" + str(v_req_qty))
    v_currencycode = mbo.getString("CDS_CUR_RES_QTY_" + str(v_req_qty))
    #storing burdenrate only into CDS_COST_BUR_PERCENT_QTY_<1,2,3,4> fields in order to add in final quote to customer cost
    # i.e for all sublevel purchase parts 
    v_burdenrateonly = round((v_unitcost * (v_burratepercen/100.00)),2)	
    v_burplusunitcost = round(v_unitcost + (v_unitcost * (v_burratepercen/100.00)),2)
    # if MAKE part then do not need to calculate burdenrate 
    # so, setting back to unitcost to recently calculated burden rate
    if(v_makebuydecision  =="MAKE"):
        v_burplusunitcost = v_unitcost	
    # apply burden rate 
    v_burwithmarkup = round(v_burplusunitcost + (v_burplusunitcost * (v_cdscustmarkup/100.00)),2)	
    #exchange rate calculation
    v_exchangewhere = "currencycodeto ='USD' and sysdate between activedate and expiredate and currencycode = '"+str(v_currencycode)+"'"
    exchangeSet = mbo.getMboSet('$$EXCHANGE','EXCHANGE',v_exchangewhere)							 
    if(exchangeSet.moveFirst() is not None):					
        v_exchangerate = exchangeSet.getMbo(0).getDouble("EXCHANGERATE")
    elif(v_currencycode == "USD" ):
        v_exchangerate = 1
    else:
        v_exchangerate = 1
    v_costquote = round((v_exchangerate*v_burwithmarkup),2)
    v_burdenrateonly = round((v_exchangerate*v_burdenrateonly),2)
    # Set the cost values
    mbo.setValue("CDS_MARKUP_QTY"+str(v_req_qty),v_burwithmarkup,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    if(v_makebuydecision  != "MAKE"):	
		mbo.setValue("CDS_BURDEN_RATE_QTY"+str(v_req_qty),v_burplusunitcost,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    mbo.setValue("CDS_CONVRATE_QTY"+str(v_req_qty),v_exchangerate,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    mbo.setValue("CDS_COST_NET_QTY_"+str(v_req_qty),v_costquote,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    mbo.setValue("CDS_COST_BUR_PERCENT_QTY_"+str(v_req_qty),v_burdenrateonly,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)

# Set quote validity
c = Calendar.getInstance() 
c.add(Calendar.MONTH,12)
d = c.getTime()
mbo.setValue("CDS_QUOTE_VALIDITY",d,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
total_lead_rec  =   0
total_cost_rec  =   0
me_total_lead_nrec  =   0
me_total_cost_nrec  =   0
v_hlevel = mbo.getInt("CDS_HLEVEL")
v_flagcost = mbo.getBoolean("CDS_FLAG_COST")
if(v_hlevel == 1 and v_quote_type=="FORMAL" and v_makebuydecision  =="MAKE" and v_flagcost):
    recMboSet = mbo.getMboSet("CDS_WO_MAN_REC_COST")
    if recMboSet:
        total_lead_rec = recMboSet.sum("LEADTIME")
        total_cost_rec = recMboSet.sum("COST")

    nonrecmboset = mbo.getMboSet("CDS_WO_MAN_NREC_COST")
    if nonrecmboset:
        me_total_lead_nrec = nonrecmboset.sum("LEADTIME")
        me_total_cost_nrec = nonrecmboset.sum("COST")
    mbo.setValue("CDS_FLAG_COST",False)        

# below section is used for calculating Manufactured and Purchanse break down details 
#According to business rule FInal quote to customer - 
#should not be included Non-recurring costs
#Should be included all purchase part's burden rates

if(v_hlevel == 1 and (v_quote_type=="FORMAL" or v_quote_type=="LIGHT")):
    # get exchange rate 
    
    v_exchgwhere = "currencycodeto ='USD' and sysdate between activedate and expiredate and currencycode = 'GBP'"
    exchgSet = mbo.getMboSet('$$EXCHANGE','EXCHANGE',v_exchgwhere)
    v_exchgrate = 1
    if(exchgSet.moveFirst() is not None):					
       v_exchgrate = exchgSet.getMbo(0).getDouble("EXCHANGERATE")
    v_hlevel1_wo  = mbo.getString("WONUM")
    mbo.setValue("WOLO5","VSA")    
    # this where condition pulls all child MAKE parts for the given top parent irrespective of hlevel
    v_manufwhereclause = "istask = 0 and cds_quote_type = 'FORMAL' and cds_makebuy_decision = 'MAKE' start with wonum = '"+str(v_hlevel1_wo)+"' connect by PRIOR wonum = parent"
    womanufmboset = mbo.getMboSet("$$WORKORDERMANUF","WORKORDER",v_manufwhereclause)
    if(womanufmboset.moveFirst() is not None):
                print "============Inside calculating MAKE parts======================"
        # Summing up all Lead Time - Recurring and  NonRecurring 
		v_tot_manuf_lt_qty_1 = womanufmboset.sum("CDS_LEADTIME_QTY_1_NREC")+womanufmboset.sum("CDS_LEADTIME_QTY_1_REC")+total_lead_rec+me_total_lead_nrec
		v_tot_manuf_lt_qty_2 = womanufmboset.sum("CDS_LEADTIME_QTY_2_NREC")+womanufmboset.sum("CDS_LEADTIME_QTY_2_REC")+total_lead_rec+me_total_lead_nrec
		v_tot_manuf_lt_qty_3 = womanufmboset.sum("CDS_LEADTIME_QTY_3_NREC")+womanufmboset.sum("CDS_LEADTIME_QTY_3_REC")+total_lead_rec+me_total_lead_nrec
		v_tot_manuf_lt_qty_4 = womanufmboset.sum("CDS_LEADTIME_QTY_4_NREC")+womanufmboset.sum("CDS_LEADTIME_QTY_4_REC")+total_lead_rec+me_total_lead_nrec
        # only non recurring cost in order to subtract from net cost 
		v_tot_manuf_nonrec_cost_qty_1 = womanufmboset.sum("CDS_COST_QTY_1_NREC")+me_total_cost_nrec
		v_tot_manuf_nonrec_cost_qty_2 = womanufmboset.sum("CDS_COST_QTY_2_NREC")+me_total_cost_nrec
		v_tot_manuf_nonrec_cost_qty_3 = womanufmboset.sum("CDS_COST_QTY_3_NREC")+me_total_cost_nrec
		v_tot_manuf_nonrec_cost_qty_4 = womanufmboset.sum("CDS_COST_QTY_4_NREC")+me_total_cost_nrec
        # non recurring cost is always GBP so converting into USD
		v_tot_manuf_nonrec_cost_qty_1 = round((v_exchgrate*v_tot_manuf_nonrec_cost_qty_1),2)
		v_tot_manuf_nonrec_cost_qty_2 = round((v_exchgrate*v_tot_manuf_nonrec_cost_qty_2),2)
		v_tot_manuf_nonrec_cost_qty_3 = round((v_exchgrate*v_tot_manuf_nonrec_cost_qty_3),2)
		v_tot_manuf_nonrec_cost_qty_4 = round((v_exchgrate*v_tot_manuf_nonrec_cost_qty_4),2)		
        #subtract non recurring cost from net cost
		mbo.setValue("CDS_COST_NET_QTY_1",mbo.getDouble("CDS_COST_NET_QTY_1")-v_tot_manuf_nonrec_cost_qty_1)
		mbo.setValue("CDS_COST_NET_QTY_2",mbo.getDouble("CDS_COST_NET_QTY_2")-v_tot_manuf_nonrec_cost_qty_2)
		mbo.setValue("CDS_COST_NET_QTY_3",mbo.getDouble("CDS_COST_NET_QTY_3")-v_tot_manuf_nonrec_cost_qty_3)
		mbo.setValue("CDS_COST_NET_QTY_4",mbo.getDouble("CDS_COST_NET_QTY_4")-v_tot_manuf_nonrec_cost_qty_4)		

		v_tot_manuf_cost_qty_1 = womanufmboset.sum("CDS_COST_QTY_1_NREC")+womanufmboset.sum("CDS_COST_QTY_1_REC")+me_total_cost_nrec+total_cost_rec
		v_tot_manuf_cost_qty_2 = womanufmboset.sum("CDS_COST_QTY_2_NREC")+womanufmboset.sum("CDS_COST_QTY_2_REC")+me_total_cost_nrec+total_cost_rec
		v_tot_manuf_cost_qty_3 = womanufmboset.sum("CDS_COST_QTY_3_NREC")+womanufmboset.sum("CDS_COST_QTY_3_REC")+me_total_cost_nrec+total_cost_rec
		v_tot_manuf_cost_qty_4 = womanufmboset.sum("CDS_COST_QTY_4_NREC")+womanufmboset.sum("CDS_COST_QTY_4_REC")+me_total_cost_nrec+total_cost_rec
                print "=======v_tot_manuf_cost_qty_1========"+str(v_tot_manuf_cost_qty_1)
                print "=======v_tot_manuf_cost_qty_2========"+str(v_tot_manuf_cost_qty_2)
                print "=======v_tot_manuf_cost_qty_3========"+str(v_tot_manuf_cost_qty_3)
                print "=======v_tot_manuf_cost_qty_4========"+str(v_tot_manuf_cost_qty_4)
        
                print "=======v_tot_manuf_lt_qty_1========"+str(v_tot_manuf_lt_qty_1)
                print "=======v_tot_manuf_lt_qty_2========"+str(v_tot_manuf_lt_qty_2)
                print "=======v_tot_manuf_lt_qty_3========"+str(v_tot_manuf_lt_qty_3)
                print "=======v_tot_manuf_lt_qty_4========"+str(v_tot_manuf_lt_qty_4)
        
        
		mbo.setValue("CDS_TOT_MANUF_LEADTIME_QTY_1",v_tot_manuf_lt_qty_1)
		mbo.setValue("CDS_TOT_MANUF_LEADTIME_QTY_2",v_tot_manuf_lt_qty_2)
		mbo.setValue("CDS_TOT_MANUF_LEADTIME_QTY_3",v_tot_manuf_lt_qty_3)
		mbo.setValue("CDS_TOT_MANUF_LEADTIME_QTY_4",v_tot_manuf_lt_qty_4)
        
		mbo.setValue("CDS_TOT_MANUF_COST_QTY_1",v_tot_manuf_cost_qty_1)
		mbo.setValue("CDS_TOT_MANUF_COST_QTY_2",v_tot_manuf_cost_qty_2)
		mbo.setValue("CDS_TOT_MANUF_COST_QTY_3",v_tot_manuf_cost_qty_3)
		mbo.setValue("CDS_TOT_MANUF_COST_QTY_4",v_tot_manuf_cost_qty_4)
    #this where condition pulls all child BUY parts for the given top parent irrespective of hlevel
    v_purwhereclause = "istask = 0 and ((cds_quote_type = 'FORMAL' and cds_makebuy_decision = 'BUY') or cds_quote_type = 'LIGHT' ) start with wonum = '"+str(v_hlevel1_wo)+"' connect by PRIOR wonum = parent"
    wopurmboset = mbo.getMboSet("$$WORKORDERPUR","WORKORDER",v_purwhereclause)
    if(wopurmboset.moveFirst() is not None):
                print "============Inside calculating BUY parts======================"
        # Summing up all Lead Time - Recurring , NonRecurring  and RFQ 
		v_tot_pur_lt_qty_1 = wopurmboset.sum("CDS_LEADTIME_QTY_1_NREC")+wopurmboset.sum("CDS_LEADTIME_QTY_1_REC")+wopurmboset.sum("CDS_QUOTE_LEADTIME_QTY_1")
		v_tot_pur_lt_qty_2 = wopurmboset.sum("CDS_LEADTIME_QTY_2_NREC")+wopurmboset.sum("CDS_LEADTIME_QTY_2_REC")+wopurmboset.sum("CDS_QUOTE_LEADTIME_QTY_2")
		v_tot_pur_lt_qty_3 = wopurmboset.sum("CDS_LEADTIME_QTY_3_NREC")+wopurmboset.sum("CDS_LEADTIME_QTY_3_REC")+wopurmboset.sum("CDS_QUOTE_LEADTIME_QTY_3")
		v_tot_pur_lt_qty_4 = wopurmboset.sum("CDS_LEADTIME_QTY_4_NREC")+wopurmboset.sum("CDS_LEADTIME_QTY_4_REC")+wopurmboset.sum("CDS_QUOTE_LEADTIME_QTY_4")
        # Summing up all cost - Recurring , NonRecurring  and RFQ 
		v_tot_pur_cost_qty_1 = wopurmboset.sum("CDS_COST_QTY_1_NREC")+wopurmboset.sum("CDS_COST_QTY_1_REC")+wopurmboset.sum("CDS_QUOTE_QTY_1")
		v_tot_pur_cost_qty_2 = wopurmboset.sum("CDS_COST_QTY_2_NREC")+wopurmboset.sum("CDS_COST_QTY_2_REC")+wopurmboset.sum("CDS_QUOTE_QTY_2")
		v_tot_pur_cost_qty_3 = wopurmboset.sum("CDS_COST_QTY_3_NREC")+wopurmboset.sum("CDS_COST_QTY_3_REC")+wopurmboset.sum("CDS_QUOTE_QTY_3")
		v_tot_pur_cost_qty_4 = wopurmboset.sum("CDS_COST_QTY_4_NREC")+wopurmboset.sum("CDS_COST_QTY_4_REC")+wopurmboset.sum("CDS_QUOTE_QTY_4")
        # set total purchase lead time 
		mbo.setValue("CDS_TOT_PURC_LEADTIME_QTY_1",v_tot_pur_lt_qty_1)
		mbo.setValue("CDS_TOT_PURC_LEADTIME_QTY_2",v_tot_pur_lt_qty_2)
		mbo.setValue("CDS_TOT_PURC_LEADTIME_QTY_3",v_tot_pur_lt_qty_3)
		mbo.setValue("CDS_TOT_PURC_LEADTIME_QTY_4",v_tot_pur_lt_qty_4)
        
        # only non recurring cost in order to subtract from net cost 
		v_tot_pur_nonrec_cost_qty_1 = wopurmboset.sum("CDS_COST_QTY_1_NREC")
		v_tot_pur_nonrec_cost_qty_2 = wopurmboset.sum("CDS_COST_QTY_2_NREC")
		v_tot_pur_nonrec_cost_qty_3 = wopurmboset.sum("CDS_COST_QTY_3_NREC")
		v_tot_pur_nonrec_cost_qty_4 = wopurmboset.sum("CDS_COST_QTY_4_NREC")
        # non recurring cost is always GBP so converting into USD
		v_tot_pur_nonrec_cost_qty_1 = round((v_exchgrate*v_tot_pur_nonrec_cost_qty_1),2)		
		v_tot_pur_nonrec_cost_qty_2 = round((v_exchgrate*v_tot_pur_nonrec_cost_qty_2),2)		
		v_tot_pur_nonrec_cost_qty_3 = round((v_exchgrate*v_tot_pur_nonrec_cost_qty_3),2)		
		v_tot_pur_nonrec_cost_qty_4 = round((v_exchgrate*v_tot_pur_nonrec_cost_qty_4),2)				

		v_tot_burdenrate_only_qty_1 = wopurmboset.sum("CDS_COST_BUR_PERCENT_QTY_1")
		v_tot_burdenrate_only_qty_2 = wopurmboset.sum("CDS_COST_BUR_PERCENT_QTY_2")
		v_tot_burdenrate_only_qty_3 = wopurmboset.sum("CDS_COST_BUR_PERCENT_QTY_3")
		v_tot_burdenrate_only_qty_4 = wopurmboset.sum("CDS_COST_BUR_PERCENT_QTY_4")
        #subtract non recurring cost from net cost and add burden cost of all child purchase parts
		mbo.setValue("CDS_COST_NET_QTY_1",mbo.getDouble("CDS_COST_NET_QTY_1")-v_tot_pur_nonrec_cost_qty_1+v_tot_burdenrate_only_qty_1)
		mbo.setValue("CDS_COST_NET_QTY_2",mbo.getDouble("CDS_COST_NET_QTY_2")-v_tot_pur_nonrec_cost_qty_2+v_tot_burdenrate_only_qty_2)
		mbo.setValue("CDS_COST_NET_QTY_3",mbo.getDouble("CDS_COST_NET_QTY_3")-v_tot_pur_nonrec_cost_qty_3+v_tot_burdenrate_only_qty_3)
		mbo.setValue("CDS_COST_NET_QTY_4",mbo.getDouble("CDS_COST_NET_QTY_4")-v_tot_pur_nonrec_cost_qty_4+v_tot_burdenrate_only_qty_4)	
        # set total purchase cost
		mbo.setValue("CDS_TOT_PURC_COST_QTY_1",v_tot_pur_cost_qty_1)
		mbo.setValue("CDS_TOT_PURC_COST_QTY_2",v_tot_pur_cost_qty_2)
		mbo.setValue("CDS_TOT_PURC_COST_QTY_3",v_tot_pur_cost_qty_3)
		mbo.setValue("CDS_TOT_PURC_COST_QTY_4",v_tot_pur_cost_qty_4)