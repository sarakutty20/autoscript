#   Description:
#   CDS_RFQ_MILES_COMP_01.py
#   Complete Supplier Allocation and Supplier RFQ Sent i.e SAL and SRS   
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    30/09/2016
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A         S Ananthan
#    
#   Launch Point Variables
#   ----------------------
#                                         Action launch point
#
#   Relationships
#   -------------

from java.util import Calendar 
from java.util import Date 
from psdi.server import MXServer 
from psdi.mbo import MboConstants 
from psdi.mbo import SqlFormat
from psdi.mbo import MboSetEnumeration
import sys

v_rfqnum = mbo.getString('RFQNUM') 
v_siteid = mbo.getString('SITEID')
v_wonum = mbo.getString("RFQ1")
v_rfqstatus = mbo.getString("STATUS")

v_ms_code = ""

if(v_rfqstatus == "INPRG" or v_rfqstatus == "SENT"):
    print "=====Inside RFQ INPRG or SENT=========="+str(v_rfqnum)+"========="+str(v_rfqstatus)
    v_ms_code = "'SAL','SRS'"

if(v_rfqstatus == "COMP"):
    print "=====Inside RFQ COMP=========="+str(v_rfqnum) +"========="+str(v_rfqstatus)
    v_ms_code = "'SQE','PAP'"  

v_whereclauseql = "istask = 1 and siteid = 'BIRM' and cds_ms_code in ("+str(v_ms_code)+") and parent = '"+str(v_wonum)+"' and exists ( select 1 from workorder wo where wo.siteid = workorder.siteid and  wo.istask = 0 and ((wo.cds_quote_type = 'FORMAL' and wo.cds_makebuy_decision = 'BUY') or wo.cds_quote_type = 'LIGHT' )  and wo.cds_hlevel = 1 and wo.status in ('INPRG','QUOTECOMP') and wo.wonum = '"+str(v_wonum)+"')"
print "==v_whereclauseql========="+str(v_whereclauseql)
woactivityset  = mbo.getMboSet('$$WOA','WORKORDER',v_whereclauseql)
#print '******** Inside CDS_RFQ_QTELN_UPD_01.py **************************'    
#Add milestone
try: 
    woactivitysetenum  = MboSetEnumeration(woactivityset)
    while (woactivitysetenum.hasMoreElements()):
        woactivitymbo = woactivitysetenum.nextMbo()
        v_currentstatus = woactivitymbo.getString("STATUS")
        print "======wo task v_currentstatus==========="+str(v_currentstatus)
        v_actfinishdate = woactivitymbo.getDate("ACTFINISH")
        if (v_currentstatus == "INPRG" or v_currentstatus == "BACKINPRG"):
            print "======Inside INPRG============="
            woactivitymbo.setValue("ACTFINISH", MXServer.getMXServer().getDate())
            woactivitymbo.changeStatus("COMP", MXServer.getMXServer().getDate(),"Automatic status")
        if (v_currentstatus == "COMP"):
            print "======Inside COMP============="
            woactivitymbo.setValue("ACTFINISH","")
            woactivitymbo.changeStatus("BACKINPRG", MXServer.getMXServer().getDate(),"Back to INPRG - Automatic status")
except:
    print "Exception: ", sys.exc_info() 
woactivityset.save()
woactivityset.reset()