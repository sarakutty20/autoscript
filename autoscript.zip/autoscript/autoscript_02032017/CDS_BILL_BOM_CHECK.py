#   Description:
#   CDS_BILL_BOM_CHECK.py
#   To send mail if any one of the least child is Make 
#   This is used for  check all leaset children is Purchased part or not 
#   If any one of the least purchased part has not been purchased previous then
#   it notifies to MRP coordinator to check cincom system and update the same in Maximo.
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    11/08/2016
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A          S Ananthan
#
#    
#   Launch Point Variables
#   ----------------------
#                                         Action launch point
#
#   Relationships
#   -------------

from java.util import Calendar 
from java.util import Date 
from psdi.app.report import ReportUtil 
from psdi.server import MXServer 
from psdi.mbo import MboConstants 
from psdi.mbo import MboSetEnumeration
from psdi.mbo import SqlFormat
from psdi.mbo import DBShortcut
from java.lang import System 
from java.rmi import RemoteException 
from java.sql import ResultSet
from java.util import Properties 
from javax.mail import Message 
from javax.mail import MessagingException 
from javax.mail import Session 
from javax.mail import Transport 
from javax.mail.internet import AddressException 
from javax.mail.internet import InternetAddress 
from javax.mail.internet import MimeMessage
from psdi.security import UserInfo 
from psdi.security import ConnectionKey 
import sys

v_custrefno = mbo.getString('CDS_CUSTOMER_REF_NO') 
v_wonum = mbo.getString('WONUM')
#Set Email Subject  			  
emailsub = "BOM does not exist for Quote Request Lines -  " + str(v_wonum)  
#Set Email Content 
emailcont = "Please find below  Quote Request Lines Customer reference no  : " + str(v_custrefno) 
#Set Email Address
v_emailid = "NO"
	
v_sender = "maxadmin@controlsdata.com"
v_cds_itemnum = mbo.getString("CDS_ITEMNUM")
# This where clause is used to identify all least part no has cds_part.part_type as M i.e Manufacutured earlier but it supposed to be 'P' according to business rule.
v_whereclauseql = "exists ( select part_nbr from cds_part where part_type = 'M' and part_nbr = CDS_BILL.comp_part_nbr ) and CONNECT_BY_ISLEAF = 1 start with prnt_part_nbr = '"+str(v_cds_itemnum)+"' connect by PRIOR comp_part_nbr = prnt_part_nbr"
cdsbillmboset = mbo.getMboSet('$$CDSBOM','CDS_BILL',v_whereclauseql)
v_fulltable = []
v_leastchildren = []
recipientAddress = []
v_isparticipated = False
if(cdsbillmboset.moveFirst() is not None):
	cdsbillmbosetenum  = MboSetEnumeration(cdsbillmboset)
	while (cdsbillmbosetenum.hasMoreElements()):
		cdsbillmbo = cdsbillmbosetenum.nextMbo()
		v_leastchild = cdsbillmbo.getString("COMP_PART_NBR")
		v_leastchildren.append(v_leastchild) 
	v_whereclauseemail = "personid in ( select RESPPARTYGROUP from PERSONGROUPTEAM where persongroup='MRP_CO')"
	emailmboset = mbo.getMboSet('$$EMAILLIST','EMAIL',v_whereclauseemail)
	# Listing out all MRP_CO email ids 
	if(emailmboset.moveFirst() is not None):
		v_isparticipated = True
		emailmbosetenum  = MboSetEnumeration(emailmboset)
		while (emailmbosetenum.hasMoreElements()):
			emailmbo = emailmbosetenum.nextMbo()
			v_email = emailmbo.getString("EMAILADDRESS")
			recipientAddress.append(v_email)
	mxServer = MXServer.getMXServer()
	# conKey and dbs object have introduced in order to execute sql select statement.
	conKey = mxServer.getSystemUserInfo().getConnectionKey()
	dbs = DBShortcut()
	dbs.connect(conKey)
	c = 0
	# Forming HTML table with parent , component part no and Hierarchy path information
	v_fulltable = []
	v_tablehdr = "<table border='1'><tr><th>Parent Part no </th><th>Comp Part no </th><th>Hierarchy Path </th></tr>"
	v_fulltable.append(v_tablehdr)	
	print "---Parent Part no------Comp Part no----------Remarks---------"
	try:
		# Below select statement listing provide table of information that contains all child information of given top level part no
		rs = dbs.executeQuery("select PRNT_PART_NBR,COMP_PART_NBR,sys_connect_by_path(comp_part_nbr,'/') FULLPATH from CDS_BILL where 1=1 start with prnt_part_nbr = '"+str(v_cds_itemnum)+"' connect by PRIOR comp_part_nbr = prnt_part_nbr ORDER SIBLINGS BY comp_part_nbr")
		# if the part no has / then cover the part no with square braces [ ] 
		if("/" in v_cds_itemnum):
			v_cds_itemnum = "["+str(v_cds_itemnum)+"]"
		while(rs.next() and v_isparticipated ):
			v_parentpartnbr = rs.getString("PRNT_PART_NBR")
			v_comppartnbr 	= rs.getString("COMP_PART_NBR")
			v_fullpath		= rs.getString("FULLPATH")
			# if the part no has / then cover the part no with square braces [ ] 			
			if("/" in v_parentpartnbr):
				v_parentpartnbr = "["+str(v_parentpartnbr)+"]"
			# if the part no has / then cover the part no with square braces [ ] 				
			if("/" in v_comppartnbr):
				v_comppartnbr = "["+str(v_comppartnbr)+"]"
			v_tablecol1 = "<tr><td>"+str(v_parentpartnbr)+"</td>"
			v_tablecol2 = "<td>"+str(v_comppartnbr)+"</td>"
			v_tablecol3 = "<td>"+str(v_cds_itemnum)+str(v_fullpath)+"</td></tr>"
			# below condition to hightlight the all least manufactured part no 
			if(v_comppartnbr in v_leastchildren):
				v_tablecol2 = "<td bgcolor='yellow'><font color='red'>"+str(v_comppartnbr)+"</font></td>"
				v_tablecol3 = "<td bgcolor='yellow'><font color='red'>"+str(v_cds_itemnum)+str(v_fullpath)+"</font></td></tr>"
			v_fulltable.append(v_tablecol1+v_tablecol2+v_tablecol3)
		v_fulltable.append("</table>")			
		rs.close()
		dbs.commit()
	except:
		print "Exception: ", sys.exc_info()
	finally:
		dbs.close()
	try:			
		v_emailsubject = "BOM does not exist for Quote Request Lines -  " + str(v_wonum) +" and Reference no - "+str(v_custrefno)
		v_emailbody = ''.join(v_fulltable)
		# sending notification to all MRP coordinators
		MXServer.sendEMail(recipientAddress, v_sender,v_emailsubject , v_emailbody)
	except:
		print "In exception*******************"