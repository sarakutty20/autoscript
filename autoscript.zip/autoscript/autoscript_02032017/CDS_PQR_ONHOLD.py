#   Description:
#   CDS_PQR_ONHOLD.py
#   CDS_CUST_REASON - Field
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    16/12/2015
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A          S Ananthan
#    
#   Launch Point Variables
#   ----------------------
#                                         Action launch point
#
#   Relationships
#   -------------


from psdi.mbo import Mbo
from psdi.mbo import MboRemote 
from psdi.mbo import MboSet
from psdi.mbo import MboSetEnumeration
from psdi.mbo import MboValue
from psdi.mbo import MboConstants
from psdi.server import MXServer
from java.util import Date
import sys

v_rfqnum = mbo.getString('RFQNUM') 
v_siteid = mbo.getString('SITEID')
v_wonum = mbo.getString("RFQ1")
v_rfqstatus = mbo.getString("STATUS")
v_cust_reason = mbo.getInt("CDS_CUST_REASON")
v_prq_desc = "Post RFQ Query (On Hold)"
v_cds_ms_code = "PQR"



def addWOActivity(v_woseq,woactivityset):
    print "=======addWOActivity=========="
    woactmbo = woactivityset.add()
    woactmbo.setValue("PARENT",v_wonum)
    woactmbo.setValue("WOSEQUENCE",v_woseq+5)
    woactmbo.setValue("DESCRIPTION",v_prq_desc)
    v_estdur = int(168)
    if(v_30Day_60Day == "60DAY"):
        v_estdur = v_estdur * 2 
    woactmbo.setValue("ESTDUR",str(v_estdur))
    woactmbo.setValue("CDS_MS_CODE",v_cds_ms_code)
    woactmbo.setValue("PARENTCHGSSTATUS",0)
    woactmbo.setValue("CDS_CUST_REASON",v_cust_reason)	
    woactmbo.setValue("ISTASK",1,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
    woactmbo.changeStatus("INPRG", MXServer.getMXServer().getDate(),"Automatic status")
    print "============="+str(woactmbo.getString("WOSEQUENCE"))
    print "============="+str(woactmbo.getString("WONUM"))
    woactivityset.save()
    return
    
print "===RFQ Status========"+str(v_rfqstatus)
wombo = mbo.getMboSet("WORKORDER").getMbo(0)
v_cds_hlevel   =  wombo.getInt("CDS_HLEVEL")
v_30Day_60Day  = wombo.getString("JPNUM")
v_quote_type   = wombo.getString("CDS_QUOTE_TYPE")
v_make_buy     = wombo.getString("CDS_MAKEBUY_DECISION") 
if(v_cds_hlevel == 1 and v_quote_type == "FORMAL" and v_make_buy == "BUY"):
    try:
        woactivityset = MXServer.getMXServer().getMboSet("WOACTIVITY", mbo.getUserInfo())
        mbo.setValue("CDS_CUST_REASON",0,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
        if(v_rfqstatus == "SENT"):
            v_whereclauseql = "istask=1 and CDS_MS_CODE='PQR' and status = 'COMP' and parent = '"+str(v_wonum)+"' order by WOSEQUENCE desc "
            print "==v_whereclauseql========="+str(v_whereclauseql)
            woactivityset.setWhere(v_whereclauseql)
            if(woactivityset.moveFirst() is not None):
                print "====Inside if====="
                woactivitymbo = woactivityset.getMbo(0)
                v_currentstatus = woactivitymbo.getString("STATUS")
                v_woseq     =   woactivitymbo.getInt("WOSEQUENCE")
                addWOActivity(v_woseq,woactivityset)
            else:
                print "====Inside Else====="        
                v_where_sqe = "istask=1 and CDS_MS_CODE='SRS' and parent = '"+str(v_wonum)+"' "
                woactivityset.reset()
                woactivityset.setWhere(v_where_sqe)
                if(woactivityset.moveFirst() is not None):
                    woactivitymbo = woactivityset.getMbo(0)
                    v_woseq     =   woactivitymbo.getInt("WOSEQUENCE")
                    print "======v_woseq======"+str(v_woseq)
                    addWOActivity(v_woseq,woactivityset)
        if(v_rfqstatus == "ONHOLD"):
            v_whereinprg = "istask=1 and CDS_MS_CODE='PQR' and status = 'INPRG' and parent = '"+str(v_wonum)+"'"
            print "==v_whereclauseql========="+str(v_whereinprg)
            woactivityset.reset()
            woactivityset.setWhere(v_whereinprg)
            if(woactivityset.moveFirst() is not None):
                woambo = woactivityset.getMbo(0)
                woambo.changeStatus("COMP", MXServer.getMXServer().getDate(),"Automatic status")
                woactivityset.save()
    except:
        print "Exception: ", sys.exc_info()