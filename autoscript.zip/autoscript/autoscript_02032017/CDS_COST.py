#   Description:
#   CDS_COST.py
#   Calculate Cost by applying hourly rate
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    10/08/2016
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A         S Ananthan
#  
#    
#   Launch Point Variables
#   ----------------------
#   Attribute launch point  CDS_WO_MAN_ADD_COST.HOURS
#
#   Relationships
#   --------------------------------------------------------------------------------------
#   Name  						  			Parent 								Child
#   --------------------------------------------------------------------------------------
#   CDS_RATESPERHOUR						CDS_WO_MAN_ADD_COST				WORKORDER
#   CDS_COMM_BURDENRATE                     WORKORDER						COMMODITIES

from java.util import Calendar 
from java.util import Date 
from psdi.server import MXServer 
from psdi.mbo import MboConstants 
from psdi.mbo import SqlFormat

# CDS_RATESPERHOUR.CDS_COMM_BURDENRATE helps to get rate per hour (Hourly Rate) based on the item commodity group e.g (Y- or SS ) 
commmboset = mbo.getMboSet("CDS_RATESPERHOUR.CDS_COMM_BURDENRATE")					
if(commmboset.moveFirst() is not None):							
	v_hourlyrate = commmboset.getMbo(0).getDouble("CDS_HOURLY_RATE")
	v_hours = mbo.getDouble("HOURS")
	v_cost =round((v_hours * v_hourlyrate),2)
# setting caluculated cost 
mbo.setValue("COST",v_cost,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)