#   Description:
#   CDS_ASSET_DEST_ARRIVAL
#   Script for To prevent entering future date
#	
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    02-Sep-2016
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A           Saravanan
#
#    
#   Launch Point Variables
#   ----------------------
#  	None
#
#   Relationships
#   -------------
#	None

from java.util import Calendar 
from java.util import Date
from psdi.server import MXServer 
from psdi.mbo import MboConstants  

def setError():
	global errorkey,errorgroup
	errorkey = "orderdatecheck"
	errorgroup = "po"

v_assetdestdate = mbo.getDate("REQUIREDDATE")
print "==============="
cal = Calendar.getInstance()
dt = cal.getTime() 
if(dt.before(v_assetdestdate)):
  print "======inside iffffffffff====dt====="+str(dt)
  print "======inside iffffffffff========="+str(v_assetdestdate)  
  setError()