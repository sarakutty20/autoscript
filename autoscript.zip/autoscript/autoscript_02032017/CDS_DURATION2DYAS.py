#   Description:
#   CDS_DURATION2DYAS.py
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    05/10/2015
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A          S Ananthan
#    
#   Launch Point Variables
#   ----------------------
#   Attribute                                     Action launch point
#
#   Relationships
#   -------------

from psdi.mbo import MboConstants
from java.util import Date


v_estdur = mbo.getDouble("ESTDUR")
if(v_estdur > 0):
	days = round(v_estdur / 24.0)
	mbo.setValue("CDS_MS_DAYS",days,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
	mbo.setFieldFlag("CDS_MS_DAYS", MboConstants.READONLY, True)
	mbo.setFieldFlag("CDS_MS_CODE", MboConstants.READONLY, True)
	v_ms_code = mbo.getString("CDS_MS_CODE") 
	if(v_ms_code != "CRV" and v_ms_code != "QPR"):
		mbo.setFieldFlag("CDS_CHILDCOMP", MboConstants.READONLY, True)