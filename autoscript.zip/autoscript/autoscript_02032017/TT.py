from java.lang import System 
from java.lang import Class
from java.rmi import RemoteException 
from java.util import Properties 
from javax.mail import Message 
from javax.mail import MessagingException 
from javax.mail import Session 
from javax.mail import Transport 
from javax.mail.internet import AddressException 
from javax.mail.internet import InternetAddress 
from javax.mail.internet import MimeMessage
import sys

props = System.getProperties()
props.setProperty("mail.transport.protocol", "smtp")
v_mailhost = props.getProperty("mail.smtp.host")
props.setProperty("mail.host", v_mailhost)
session = Session.getDefaultInstance(props, None)
message = MimeMessage(session)
recipientAddress = []
v_email = ""
v_whereclauseemail = "personid in ( select RESPPARTYGROUP from PERSONGROUPTEAM where persongroup='MRP_CO')"
emailmboset = mbo.getMboSet('$$EMAILLIST','EMAIL',v_whereclauseemail)
if(emailmboset.moveFirst() is not None):
	for j in range(0,emailmboset.count()):
		emailmbo = emailmboset.getMbo(j)
		v_email = emailmbo.getString("EMAILADDRESS")
		recipientAddress.append(InternetAddress(v_email))
		print "*************v_email*****************************"+str(v_email)
try:
	message.setContent("<h1>Hello</h1>", "text/html")
	message.setSender(InternetAddress("maxadmin@controlsdata.com"))
	message.setSubject("test E-mail")
	message.setText("Test email   body============= 11082016 ")
        print "**********************TT MAIL  ************************************"
	#message.addRecipient(Message.RecipientType.TO,InternetAddress(v_email))
	message.addRecipients(Message.RecipientType.TO,recipientAddress)
	Transport.send(message)
except:
	print "Exception: ", sys.exc_info()