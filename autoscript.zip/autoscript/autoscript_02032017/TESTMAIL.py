import smtplib

print "**************In TESTMAIL**************************"
sender = "maxadmin@controlsdata.com"
receivers = ["cds_comm4@test.controlsdata.com"]

message = " This is a test e-mail message."


try:
   smtpObj = smtplib.SMTP("172.24.24.171")
   smtpObj.sendmail(sender, receivers, message)         
   print "**********************TESTMAIL********************88Successfully sent email"
except SMTPException:
   print "Error: ****************TESTMAIL*****************************unable to send email"