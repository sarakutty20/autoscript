#   Description:
#   CDS_RFQ_AWD_CAN_01.py
#   To notify to suppliers that RFQ has been cancelled due to some reason.
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    25/11/2015
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A          S Ananthan
#
#    
#   Launch Point Variables
#   ----------------------
#                                         Action launch point
#
#   Relationships
#   -------------

from psdi.server import MXServer 
from psdi.mbo import MboSetEnumeration  

v_rfqnum = mbo.getString('RFQNUM') 
v_siteid = mbo.getString('SITEID')
 
#Set Email Address
v_emailid = "NO"

v_sender = "maxadmin@controlsdata.com"
v_whereclauseql = "siteid = '"+str(v_siteid)+"' and rfqnum = '"+str(v_rfqnum)+"'"
rfqvendorSet = mbo.getMboSet('$$RFQV','RFQVENDOR',v_whereclauseql)
rfqvendorsetenum  = MboSetEnumeration(rfqvendorSet)
# Identifying all rfqvendor and contact email id 
while (rfqvendorsetenum.hasMoreElements()):
	rfqvendormbo = rfqvendorsetenum.nextMbo()
	if(rfqvendormbo is not None):
		v_emailid = rfqvendormbo.getString("EMAIL")
		v_vendor  = rfqvendormbo.getString("VENDOR")
		try:
			v_emailsubject = "RFQ "+str(v_rfqnum)+" Cancelled "
			v_emailbody = "We are sorry to inform you that the RFQ "+str(v_rfqnum)+" has been cancelled "
			#This method is used to send mail 
			MXServer.sendEMail(v_emailid, v_sender,v_emailsubject , v_emailbody)
		except:
			print "In exception*******************"