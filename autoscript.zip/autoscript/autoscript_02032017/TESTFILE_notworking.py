import os
import sys

f = open("E:\\temp\\pythonfile\\tobeprocessed\\VHMETER01.txt", "r")
copy = open("E:\\temp\\pythonfile\\processed\\VHMETER01.txt", "w")
for line in f:
    print "====Lines========"+str(line)
    copy.write(line)
f.close()
copy.close()