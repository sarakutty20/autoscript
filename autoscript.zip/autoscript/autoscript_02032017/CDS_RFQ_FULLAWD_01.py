#   Description:
#   CDS_RFQ_FULLAWD_01.py
#   To send awarded and not awarded lines to Suppliers
#
#   Subversion Info
#   ---------------
#   $Id$
#
#
#   Revision History
#   ----------------
#   Created:    25/11/2015
#   --------------------------------------------------------------------------
#   Version Description                             CMS Ref         Changed By
#   -------+---------------------------------------+---------------+----------
#   1.0      Initial version                            N/A          S Ananthan
#
#    
#   Launch Point Variables
#   ----------------------
#                                         Action launch point
#
#   Relationships
#   -------------

from psdi.server import MXServer 
from psdi.mbo import MboConstants
from psdi.mbo import MboSetEnumeration 

v_rfqnum = mbo.getString('RFQNUM') 
v_siteid = mbo.getString('SITEID')
 
#Set Email Address
v_emailid = "NO"
	
v_sender = "maxadmin@controlsdata.com"
v_whereclauseql = "siteid = '"+str(v_siteid)+"' and rfqnum = '"+str(v_rfqnum)+"'"
rfqvendorSet = mbo.getMboSet('$$RFQV','RFQVENDOR',v_whereclauseql)
v_fulltable = []
v_isparticipated = False
rfqvendorsetenum  = MboSetEnumeration(rfqvendorSet)	
# retrieve all rfqvendor 
while (rfqvendorsetenum.hasMoreElements()):
	rfqvendormbo = rfqvendorsetenum.nextMbo()	
	v_emailid = rfqvendormbo.getString("EMAIL")
	v_vendor  = rfqvendormbo.getString("VENDOR")
	v_whereqline = "siteid = '"+str(v_siteid)+"' and rfqnum = '"+str(v_rfqnum)+"' and vendor = '"+str(v_vendor)+"'"
	rfqqtnlineSet = mbo.getMboSet('$$RFQQL','QUOTATIONLINE',v_whereqline)
	v_fulltable = []
	v_tablehdr = "<table><tr><th>RFQNUM</th><th>RFQLINENUM</th><th>VENDOR</th><th>ITEMNUM</th><th>ORDERQTY</th><th>ISAWARDED</th></tr>"
	#print "---RFQ------RFQLINENUM----------VENDOR----------ITEMNUM-------QTY----------ISAWARDED"
	v_isparticipated = False
	v_fulltable.append(v_tablehdr)
        rfqqtnlineenum  = MboSetEnumeration(rfqqtnlineSet)
        while (rfqqtnlineenum.hasMoreElements()):
	   rfqqtnlinembo = rfqqtnlineenum.nextMbo()	
        # quote have been received for this vendor 
           v_isparticipated = True
	   v_rfqlinenum = rfqqtnlinembo.getString("RFQLINENUM")
	   v_itemnum = rfqqtnlinembo.getString("ITEMNUM")
	   v_orderqty = rfqqtnlinembo.getString("ORDERQTY")
	   v_isawarded = rfqqtnlinembo.getString("ISAWARDED")
	   if(v_isawarded == "Y"):
	      v_isawarded = "YES"
	   else:  
		  v_isawarded = "NO"	
	   v_tablerow = "<tr><td>"+str(v_rfqnum)+"</td><td>"+str(v_rfqlinenum)+"</td><td>"+str(v_vendor)+"</td><td>"+str(v_itemnum)+"</td><td>"+str(v_orderqty)+"</td><td>"+str(v_isawarded)+"</td></tr>"
	   v_fulltable.append(v_tablerow)	
	try:
		v_emailsubject = "RFQ "+str(v_rfqnum)+" Awarded details "
                v_emailbody = ""
        # sending mail to participated vendor
		if(v_isparticipated == True):
			v_fulltable.append("</table>")
			v_emailbody = ''.join(v_fulltable)
        # sending mail quote have not received from vendor 
		if(v_isparticipated ==  False):
			v_fulltable = ["RFQ "+str(v_rfqnum)+" has been awarded to other vendor "]
			v_emailbody = ''.join(v_fulltable)
		MXServer.sendEMail(v_emailid, v_sender,v_emailsubject , v_emailbody)
                commlogset = mbo.getMboSet("COMMLOG")
                commlogmbo = commlogset.add(MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                commlogmbo.setValue("SENDTO",v_emailid,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                commlogmbo.setValue("SENDFROM","maxadmin@test.controlsdata.com",MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)							
                commlogmbo.setValue("SUBJECT",v_emailsubject +"-- Autoscript ",MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                commlogmbo.setValue("CREATEBY","MAXADMIN",MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)	
                commlogmbo.setValue("CREATEDATE",Date(),MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)	
                commlogmbo.setValue("OWNERTABLE","RFQ",MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)	
                commlogmbo.setValue("MESSAGE",v_emailbody,MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)
                commlogmbo.setValue("OWNERID",mbo.getString("RFQID"),MboConstants.NOACCESSCHECK | MboConstants.NOVALIDATION_AND_NOACTION)													
	except:
		print "In exception*******************"